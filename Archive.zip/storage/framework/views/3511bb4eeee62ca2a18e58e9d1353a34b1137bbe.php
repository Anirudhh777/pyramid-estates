<?php $__env->startSection('front-page'); ?>
	<div class="admin">
		<div class="wrapper fadeInDown">
		  <div id="formContent">
		  	<?php if(Route::currentRouteName() === 'dashboard'): ?>
		  		<form role="form" method="POST" action="<?php echo e(secure_url('/admin_login')); ?>">
			    	<?php echo e(csrf_field()); ?>

			      <input type="email" class="fadeIn second" name="email" placeholder="login" required="">
			      <input type="password" class="fadeIn third" name="password" placeholder="password" required="">
			      <input type="submit" class="fadeIn fourth" value="Log In">
			    </form>
			    <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 2): ?>
						<p class="login-error">Credentials do not match, please try again.</p>
				<?php endif; ?>
			    <div id="formFooter">
			      <a class="underlineHover" href="#">Forgot Password?</a>
			    </div>
			<?php else: ?>
				<form role="form" method="POST" action="<?php echo e(secure_url('/admin_register')); ?>">
			    	<?php echo e(csrf_field()); ?>

			    	<input type="text" class="fadeIn second" name="name" placeholder="name" required="">
			     	<input type="email" class="fadeIn second" name="email" placeholder="login" required="">
			      	<input type="password" class="fadeIn third" name="password" placeholder="password" required="">
			      	<input type="submit" class="fadeIn fourth" value="Register">
			    </form>
			 <?php endif; ?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/pyramidestates/resources/views/backend/dashboard.blade.php ENDPATH**/ ?>