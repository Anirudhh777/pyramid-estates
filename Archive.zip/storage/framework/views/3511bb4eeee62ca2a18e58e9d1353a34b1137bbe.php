<?php $__env->startSection('front-page'); ?>
<div class="container">
	<div class="admin-panel">
		<a href="<?php echo e(secure_url('/admin/dashboard/buyers')); ?>">Buyers List</a>
		<a href="<?php echo e(secure_url('/admin/dashboard/sellers')); ?>">Sellers List</a>
		<a href="<?php echo e(secure_url('/admin/logout')); ?>">Logout</a>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/pyramidestates/resources/views/backend/dashboard.blade.php ENDPATH**/ ?>