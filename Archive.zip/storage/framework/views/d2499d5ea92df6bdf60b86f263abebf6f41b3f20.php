<?php $__env->startSection('front-page'); ?>
<div class="container-fluid">
	<div class="admin-panel">
		<div class="view">
			<a href="<?php echo e(secure_url('/admin/dashboard/buyers')); ?>">Buyers List</a>
			<a href="<?php echo e(secure_url('/admin/dashboard/sellers')); ?>">Sellers List</a>
			<a href="<?php echo e(secure_url('/admin/logout')); ?>">Logout</a>
		</div>
		<h2><?php echo e($type); ?></h2>
		<div class="table-responsive">
			<table class="table table-bordered">
			    <thead>
			      <tr>
			        <th>Name</th>
			        <th>Phone</th>
			        <th>Email</th>
			        <th>User Type</th>
			        <th>Prop Type</th>
			        <th>Sub Type</th>
			        <th>Bedrooms</th>
			        <th>Locations</th>
			        <th>Area</th>
			        <th>Budget</th>
			        <th>Additional</th>
			      </tr>
			    </thead>
			    <tbody>
			    	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    		<tr>
			    			<td><?php echo e($user->name); ?></td>
			    			<td><?php echo e($user->phone); ?></td>
							<td><?php echo e($user->email); ?></td>
							<td><?php echo e($user->user_type); ?></td>
							<td><?php echo e($user->property_type); ?></td>
							<td><?php echo e($user->property_sub_type); ?></td>
							<td><?php echo e($user->bedrooms); ?></td>
							<td><?php echo e($user->locations); ?></td>
							<td><?php echo e($user->area); ?></td>
							<td><?php echo e($user->budget); ?></td>
							<td><?php echo e($user->additional); ?></td>
			    		</tr>
			    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    </tbody>
	  		</table>
	  	</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/pyramidestates/resources/views/backend/view.blade.php ENDPATH**/ ?>